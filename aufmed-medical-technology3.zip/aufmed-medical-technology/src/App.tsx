/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { translations } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import AboutSection from './components/AboutSection';
import ProductsSection from './components/ProductsSection';
import ContactSection from './components/ContactSection';
import { Sparkles, ArrowUp, Github } from 'lucide-react';

// Static assets generated via image-generation tool
const HERO_BG = '/src/assets/images/aufmed_hero_bg_1781823361845.jpg';
const CORP_HQ = '/src/assets/images/aufmed_corp_hq_1781823378171.jpg';
const PRODUCT_TECH = '/src/assets/images/aufmed_product_tech_1781823392707.jpg';

export default function App() {
  const [lang, setLang] = useState('zh'); // Starts with Chinese as comfortable default

  const t = translations[lang] || translations.zh;
  const isRtl = t.dir === 'rtl';

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div
      className="min-h-screen bg-pitch-black text-white flex flex-col font-sans select-none overflow-x-hidden antialiased"
      style={{ direction: t.dir }}
    >
      {/* Background ambient lighting blobs matching custom color parameters */}
      <div className="fixed top-0 left-1/4 w-[600px] h-[600px] bg-cyber-cyan/[0.012] rounded-full blur-[140px] pointer-events-none z-0" />
      <div className="fixed bottom-1/4 right-1/4 w-[500px] h-[500px] bg-cyber-cyan/[0.012] rounded-full blur-[120px] pointer-events-none z-0" />

      {/* 1. Header with dynamic multilingual support */}
      <Header currentLang={lang} setLang={setLang} t={t} />

      {/* Main Content Layout */}
      <main className="flex-grow z-10">
        {/* 2.首屏Hero section with visual background, switch, CTA Actions */}
        <Hero t={t} heroBgUrl={HERO_BG} />

        {/* 3. AufMed医疗科技集团介绍模块 with metrics, corporate graphics & milestone timeline */}
        <AboutSection t={t} hqImgUrl={CORP_HQ} />

        {/* 4. 精选产品服务模块 with deep specifications, cards & diagnostic hardware views */}
        <ProductsSection t={t} productImgUrl={PRODUCT_TECH} />

        {/* 5. 页尾联系模块 with fully integrated secure form dispatches */}
        <ContactSection t={t} />
      </main>

      {/* 6. Footer section with brand signatures and back-to-top */}
      <footer id="aufmed-global-footer" className="border-t border-white/10 bg-black py-16 px-6 sm:px-8 relative z-10 overflow-hidden">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8">
          
          {/* Brand Signature */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-sans text-sm font-black text-white tracking-widest">AUFMED GROUP<span className="text-cyber-cyan">.</span></span>
              <span className="font-mono text-[9px] uppercase text-white/30 tracking-widest">{lang} mode</span>
            </div>
            <p className="text-white/40 font-sans text-xs max-w-sm leading-relaxed">
              {t.footer.tagline}
            </p>
          </div>

          {/* Designer Identity Credits */}
          <div className="flex flex-col items-center md:items-end text-center md:text-right gap-2">
            <span className="font-mono text-[10px] text-cyber-cyan tracking-widest uppercase font-bold">
              {t.footer.designerIdentity}
            </span>
            <span className="font-sans text-[11px] text-white/30">
              {t.footer.legal} | {t.footer.allRightsReserved}
            </span>
          </div>

          {/* Controls: back to top (zero corners rect style) */}
          <button
            onClick={scrollToTop}
            id="back-to-top-btn"
            className="p-3.5 border border-white/10 bg-pitch-black hover:bg-black hover:border-cyber-cyan text-white/75 hover:text-cyber-cyan rounded-none transition group cursor-pointer"
            title="Return to Zenith"
          >
            <ArrowUp className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>
      </footer>
    </div>
  );
}
