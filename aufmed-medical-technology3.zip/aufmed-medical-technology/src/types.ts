export interface NavItems {
  home: string;
  about: string;
  products: string;
  contact: string;
}

export interface Stat {
  value: string;
  label: string;
}

export interface Milestone {
  year: string;
  title: string;
  desc: string;
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  desc: string;
  capabilities: string[];
  specs: { name: string; value: string }[];
  problem: string;
  approach: string;
}

export interface TranslationSchema {
  dir: 'ltr' | 'rtl';
  nav: NavItems;
  hero: {
    badge: string;
    title: string;
    highlight: string;
    subtitle: string;
    ctaPrimary: string;
    ctaSecondary: string;
  };
  intro: {
    badge: string;
    title: string;
    subtitle: string;
    paragraphs: string[];
    statsTitle: string;
    stats: Stat[];
    milestonesTitle: string;
    milestones: Milestone[];
  };
  products: {
    badge: string;
    title: string;
    subtitle: string;
    viewDetails: string;
    capabilitiesTitle: string;
    specsTitle: string;
    problemTitle: string;
    approachTitle: string;
    items: ProductItem[];
  };
  contact: {
    badge: string;
    title: string;
    subtitle: string;
    hqTitle: string;
    hqAddress: string;
    phone: string;
    email: string;
    formName: string;
    formOrg: string;
    formInquiryType: string;
    formInquiryOptions: string[];
    formMessage: string;
    formSubmit: string;
    successMessage: string;
    placeholderName: string;
    placeholderOrg: string;
    placeholderMessage: string;
  };
  footer: {
    tagline: string;
    legal: string;
    allRightsReserved: string;
    designerIdentity: string;
  };
}

export const translations: Record<string, TranslationSchema> = {
  zh: {
    dir: 'ltr',
    nav: {
      home: '首屏',
      about: '集团介绍',
      products: '精选产品',
      contact: '联系我们',
    },
    hero: {
      badge: '生物物理与数字计算 convergence',
      title: '以高超物理学与细胞智能',
      highlight: '重构生命医疗科技的边界',
      subtitle: 'AufMed 医疗科技集团聚焦分子靶向输送、超高分辨率细胞诊断和量子生物模拟，为全球精英研发机构与临床应用提供精准范式。',
      ctaPrimary: '探索前沿系统',
      ctaSecondary: '与研究员对话',
    },
    intro: {
      badge: '关于 AUFMED',
      title: '融合分子物理学与前瞻工业设计',
      subtitle: '我们深信：最高端的医疗科技，必然是科学真理与极致美学的究极表现。',
      paragraphs: [
        'AufMed 医疗科技集团源于欧陆前沿实验室，致力于将原子级物理操纵技术与活体细胞计算相融合。我们不追求常规的被动治疗，而是研发具有主动预测与微观重塑能力的颠覆性系统。',
        '作为由视觉设计师、AI 架构师及品牌学者联合打造的技术重镇，AufMed 在保持医学严谨的同时，将结构主义美学理念深度融入硬件工程与人机界面（HMI）设计之中。'
      ],
      statsTitle: '全球科研度量值',
      stats: [
        { value: '12', label: '全球联合研究中心' },
        { value: '420+', label: '底层物理与算法专利' },
        { value: '1.2nm', label: '最高靶向输送精度' },
        { value: '99.4%', label: '分子模拟预测咬合度' }
      ],
      milestonesTitle: '发展里程碑',
      milestones: [
        { year: '2020', title: '集团联合创立', desc: '在柏林和上海同步成立生物物理多模态研究所。' },
        { year: '2022', title: '突破一纳米极限', desc: '成功演示首款具备原子态反馈的超声分子马达输送器。' },
        { year: '2024', title: 'AI 物理引擎上线', desc: '发布「AetherBio-V1」模型，预测蛋白质折叠微扰动力学。' },
        { year: '2026', title: '全面临床与艺术融合', desc: '新一代医疗人机界面斩获国际顶级设计至尊奖。' }
      ]
    },
    products: {
      badge: '精选系统与产品',
      title: '重新定义干预模式的科技集群',
      subtitle: 'AufMed 将深奥复杂的算法与细胞反应，封装进极致优雅且坚不可摧的操作架构中。',
      viewDetails: '技术细节与指标',
      capabilitiesTitle: '系统能力特征',
      specsTitle: '学术级技术参数',
      problemTitle: '应对痛点需求',
      approachTitle: '技术突破解法',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: '主动分子靶向纳米运载系统',
          desc: '基于电磁场精确诱导的智能脂质体纳米运载载体，完美实现对特定靶细胞膜的无损穿透与药重释放控制。',
          capabilities: [
            '多物理场精确诱导定位，无需生化配体介入',
            '膜表面流体动力学阻力自适应调控',
            '全时态胞内浓度实时阻抗追踪技术'
          ],
          specs: [
            { name: '几何平均径', value: '15.4 nm ± 0.8 nm' },
            { name: '载药包封率', value: '≥ 94.2%' },
            { name: '电荷释放延迟', value: '微秒级可控' }
          ],
          problem: '传统药物投递系统由于特异性不足，导致健康的周围组织受到毒副作用伤害，并在跨膜输送时损耗巨大。',
          approach: 'Vector-X10 通过微观相变反应，使用外界指向脉冲精准激活，可在原子级精度下对病灶组织释放高浓有效荷载。'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: '亚细胞三维全息光谱量子扫描仪',
          desc: '非侵入式亚细胞活体扫描系统，可在分子级别捕捉超快细胞生理活动，打破时间和空间分辨率极限。',
          capabilities: [
            '超快飞秒级激光无损高光谱探测制图',
            '活体组织深部散射纠错多阶重建系统',
            '实时胞苷动态甲基化数字孪生测绘'
          ],
          specs: [
            { name: '横向分辨率', value: '4.2 Å (埃级精度)' },
            { name: '采样延迟', value: '< 2.4 fs' },
            { name: '成像景深', value: '最大 800 μm 活体穿透' }
          ],
          problem: '传统生物染色成像对活体细胞造成不可逆毒性侵蚀，且难以支持实时的多维动态极速捕捉。',
          approach: 'Chronos-Spectrum 基于量子弱测量解缠技术，无需任何化学染色，直接解算自发拉曼散射，呈现实时活体微观画面。'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: '高密度突触生物电导反馈接口',
          desc: '用于超精细神经运动中枢重建与信号重编码的生物相容性软质突触电极阵列。',
          capabilities: [
            '高度碳纳米复合透水性生物膜包覆技术',
            '2048 点自适应抗阻突触耦合电极矩阵',
            '端侧高维神经网络低时延翻译器'
          ],
          specs: [
            { name: '电导率矩阵', value: '1.2 × 10^4 S/m' },
            { name: '生物极化电位', value: '< 10 μV' },
            { name: '柔性基底厚度', value: '3.5 μm (极薄)' }
          ],
          problem: '由于严重的排异反应与机械性能不匹配，现有的脑机及外周神经接口易导致局部胶质瘢痕和信号快速衰泄。',
          approach: 'Synapse-Link 采用三维拟胚胎形貌生长工艺，促使周围星形胶质细胞自然共生包围，实现真正一级的突触无创对插。'
        }
      ]
    },
    contact: {
      badge: '深度对话',
      title: '与 AufMed 创新架构师取得联系',
      subtitle: '我们提供定制化的系统开发咨询、临床科研合作，及极高端的技术品牌设计联合研发。',
      hqTitle: '全球卓越中心地址',
      hqAddress: '慕尼黑总院: Leopoldstraße 244, 80807 München, Germany\n上海前沿设计院: 滨江大道 200 号, 200120 中国上海',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: '尊称',
      formOrg: '所属机构 / 实验室',
      formInquiryType: '咨询意向',
      formInquiryOptions: [
        '学术科研机构联合开发',
        '临床实验及特许试验部署',
        '高科技产品体验与品牌设计共建',
        '私募资本与战略股权合作'
      ],
      formMessage: '合作设想与技术诉求简述',
      formSubmit: '发送安全邮件加密请求',
      successMessage: '您的技术请求已被加密并发送至 AufMed 多语种沟通决策小组。我们将在24小时内为您安排专门的研发代表。',
      placeholderName: '例如：张华 博士',
      placeholderOrg: '例如：前沿生物计算实验室 / 某顶尖临床医院',
      placeholderMessage: '请大致叙述您当前的研究目标，以及希望借由 AufMed 哪项系统方案缩短研发周期。'
    },
    footer: {
      tagline: '重构生命序列，执笔物理终点。',
      legal: '德国 AufMed 医疗科技集团有限公司 © All Rights Reserved.',
      allRightsReserved: '保留一切解释权。通过临床许可标准检验。',
      designerIdentity: 'AufMed 视觉工作室 // AI 与品牌设计体系'
    }
  },
  en: {
    dir: 'ltr',
    nav: {
      home: 'Home',
      about: 'About Group',
      products: 'Selected Products',
      contact: 'Reach Us',
    },
    hero: {
      badge: 'BIOPHYSICS AND COMPUTATIONAL CONVERGENCE',
      title: 'With Precision Physics',
      highlight: 'Redefine the Frontiers of Life',
      subtitle: 'AufMed Medical Technology Group focuses on molecular targeted delivery, ultra-resolution cellular diagnostics, and quantum bio-simulations, setting new standards for global elite labs.',
      ctaPrimary: 'Explore Front-end Systems',
      ctaSecondary: 'Talk with Researchers',
    },
    intro: {
      badge: 'ABOUT AUFMED',
      title: 'Bridging Molecular Physics and Avant-Garde Design',
      subtitle: 'We believe: The absolute peak of medical technology is the ultimate alignment of scientific truth and deep structural beauty.',
      paragraphs: [
        'Originating from elite European biophysics laboratories, AufMed Group merges atomic-level spatial manipulations with in-vivo bio-computation, engineering systems that proactively intercept pathological states.',
        'As an ecosystem designed collaboratively by visual designers, AI researchers, and brand philosophers, we strictly honor clinical rigor while integrating architectural clean lines into complex hardware and Human-Machine Interfaces.'
      ],
      statsTitle: 'Global Research Metrics',
      stats: [
        { value: '12', label: 'Collaborative R&D Hubs' },
        { value: '420+', label: 'Proprietary Core Patents' },
        { value: '1.2nm', label: 'Targeting Error Margin' },
        { value: '99.4%', label: 'Simulation Match Rate' }
      ],
      milestonesTitle: 'Milestones of Evolution',
      milestones: [
        { year: '2020', title: 'Group Founding', desc: 'Simulated launch of multimodal biophysics institutes in Berlin and Shanghai.' },
        { year: '2022', title: 'Breaking the 1nm Barrier', desc: 'Successfully demonstrated acoustic molecular delivery rotors.' },
        { year: '2024', title: 'AetherBio AI Core', desc: 'Introduced deep neural fold predictor for atomic dynamic protein simulations.' },
        { year: '2026', title: 'Aesthetic Pinnacle', desc: 'The new medical UI suite won supreme global design accolades.' }
      ]
    },
    products: {
      badge: 'PRODUCT PORTFOLIO',
      title: 'Decisive Tech-Clusters Shaping Intervention',
      subtitle: 'AufMed wraps highly complex biological simulations into user interfaces of extreme elegance and absolute reliability.',
      viewDetails: 'Technical Metrics & Specifications',
      capabilitiesTitle: 'System Features',
      specsTitle: 'Academic Level Parameters',
      problemTitle: 'Core Pain-points Resolved',
      approachTitle: 'Strategic Solutions',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: 'Active Targeting Liposomal Nano-carrier',
          desc: 'Electromagnetically-guided lipid nanocapsules engineered for non-destructive cell membrane penetration and precise dosage discharge.',
          capabilities: [
            'Multi-field spatial active targeting, avoiding chemical modifier decay',
            'Self-adaptive shell hydrodynamics for variable blood-flow shear stress',
            'Real-time impedance-based tracking within sub-cellular grids'
          ],
          specs: [
            { name: 'Average Diameter', value: '15.4 nm ± 0.8 nm' },
            { name: 'Encapsulation Efficiency', value: '≥ 94.2%' },
            { name: 'Discharge Delay', value: 'Microsecond scale control' }
          ],
          problem: 'Conventional vector-delivery lacks cellular affinity, prompting systemic toxicity and huge degradation prior to reaching intercellular areas.',
          approach: 'Vector-X10 utilizes physical state transitions triggered by external impulses, assuring localized drug delivery at atomic grid accuracy.'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: 'Sub-cellular 3D Optical Cryo Scanner',
          desc: 'Non-invasive sub-cellular real-time live scanner capturing instant biological shifts, overcoming historic spatial diffraction limits.',
          capabilities: [
            'Femtosecond laser dispersion non-destructive spectral mapping',
            'Deep tissue light-scattering correction via high-order reconstructive algorithm',
            'Digital Twin rendering of cyto-methylation dynamics'
          ],
          specs: [
            { name: 'Lateral Resolution', value: '4.2 Å (Angstrom accuracy)' },
            { name: 'Latency', value: '< 2.4 fs' },
            { name: 'Depth of Penetration', value: 'Up to 800 μm in-vivo' }
          ],
          problem: 'Historical staining methods irreversibly toxicify cellular environments, preventing live dynamic long-exposure tracking.',
          approach: 'Chronos-Spectrum utilizes quantum weak measurement algorithms to compute spontaneous Raman scattering, producing beautiful, dye-free micro cinematic graphics.'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: 'High-Density Biocompatible Synaptic Grid',
          desc: 'Super-flexible macroelectrode matrix ensuring perfect motor neural coupling and bidirectional translation of electrical fields.',
          capabilities: [
            'Hydro-permeable carbon-nanotube bio-membrane sheath',
            '2048-channel high-impedance customizable micro-contact map',
            'Edge-computed fast artificial neural translation decoder'
          ],
          specs: [
            { name: 'Conductivity Grid', value: '1.2 × 10^4 S/m' },
            { name: 'Polarization Voltage', value: '< 10 μV' },
            { name: 'Membrane Thickness', value: '3.5 μm (Ultra-thin)' }
          ],
          problem: 'Stiff neural interfaces trigger strong foreign-body immunological reactions, leading to cellular scarring and instant signal loss.',
          approach: 'Synapse-Link stimulates astrocyte-friendly integration, creating a natural, scar-free bridge with real neural pathways.'
        }
      ]
    },
    contact: {
      badge: 'SECURE LINK',
      title: 'Connect with AufMed Architects',
      subtitle: 'Providing customized hardware design consultancy, clinical deployment support, and premium technological brand design collaboration.',
      hqTitle: 'Global Research Hubs',
      hqAddress: 'München Head: Leopoldstraße 244, 80807 München, Germany\nShanghai Studio: No. 200 Bingjiang Blvd, Shanghai, China',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: 'Full Name',
      formOrg: 'Organization / Institute',
      formInquiryType: 'Inquiry Pathway',
      formInquiryOptions: [
        'Academia Joint R&D Partnership',
        'Investigational Device Deployment',
        'Product Usability & Design Joint Project',
        'Private Capital & Strategic Investment'
      ],
      formMessage: 'Brief Proposal & Target Objectives',
      formSubmit: 'Submit Encrypted Routing Request',
      successMessage: 'Your message has been encrypted and routed to our executive staff. A designated partner manager will respond within 24 hours.',
      placeholderName: 'e.g. Dr. Helena Vance',
      placeholderOrg: 'e.g. MIT Biosensor Lab',
      placeholderMessage: 'Briefly define the parameters of your research, and which AufMed system you intend to leverage.'
    },
    footer: {
      tagline: 'Rewriting biological sequences is our visual art.',
      legal: 'AufMed Medical Technology Group GmbH © All Rights Reserved.',
      allRightsReserved: 'Approved for research and advanced clinical evaluation programs.',
      designerIdentity: 'Designed by AufMed Studio // AI & Brand Creative Division'
    }
  },
  de: {
    dir: 'ltr',
    nav: {
      home: 'Start',
      about: 'Über uns',
      products: 'Produkte',
      contact: 'Kontakt',
    },
    hero: {
      badge: 'KONVERGENZ VON BIOPHYSIK UND ALGORITHMEN',
      title: 'Mit Präzisionsphysik',
      highlight: 'Die Grenzen der Biomedizin neu definieren',
      subtitle: 'AufMed erforscht und entwickelt molekulare Trägersysteme, ultrahochauflösende Zell-Scanner und Quantenmodellierungen für Spitzenlabore weltweit.',
      ctaPrimary: 'Systeme erkunden',
      ctaSecondary: 'Forscher einladen',
    },
    intro: {
      badge: 'ÜBER AUFMED',
      title: 'Synthese aus Biophysik und Konstruktivistischem Design',
      subtitle: 'Wir glauben: Wahre biomedizinische Innovation liegt in der absoluten Verschmelzung von Wissenschaft und eleganter Formgebung.',
      paragraphs: [
        'Entstanden in europäischen Spitzenlaboren für Biophysik, kooperiert die AufMed Gruppe mit führenden Universitäten, um atomgenaue Trägersubstanzen und bio-digitale Sensornetzwerke zu entwickeln.',
        'Als technologie- und designorientiertes Unternehmen integrieren wir minimalistische Geometrien und intuitive Interaktion in hochkomplexe klinische Apparaturen.'
      ],
      statsTitle: 'Forschungsmetriken',
      stats: [
        { value: '12', label: 'Globale Labore' },
        { value: '420+', label: 'Eigene Patente' },
        { value: '1.2nm', label: 'Zielpräzision' },
        { value: '99.4%', label: 'Simulation-Korrelation' }
      ],
      milestonesTitle: 'Meilensteine',
      milestones: [
        { year: '2020', title: 'Gründung', desc: 'Gemeinsame Gründung der Institute in Berlin und Shanghai.' },
        { year: '2022', title: 'Sub-Nanometer-Schwelle', desc: 'Präsentation des ersten akustisch regulierten Vektors.' },
        { year: '2024', title: 'AetherBio AI', desc: 'Einführung des ML-Modells zur Berechnung von Proteinfaltungen.' },
        { year: '2026', title: 'Design-Exzellenz', desc: 'Auszeichnung unserer klinischen Benutzeroberfläche mit globalen Ehren.' }
      ]
    },
    products: {
      badge: 'SYSTEM-PORTFOLIO',
      title: 'Zukunftsweisende Systeme für zelluläre Intervention',
      subtitle: 'Wir kapseln komplexe mikrophysikalische Vorgänge in Steuerungsstrukturen von zeitloser Klarheit.',
      viewDetails: 'Technische Spezifikationen',
      capabilitiesTitle: 'Systemeigenschaften',
      specsTitle: 'Technische Kenngrößen',
      problemTitle: 'Gelöstes biologisches Problem',
      approachTitle: 'Unser technologischer Ansatz',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: 'Elektromagnetischer Nanoträger',
          desc: 'Elektromagnetisch kalibrierte Liposomen für die zerstörungsfreie Zellmembran-Interpenetration und hochspezifische Dosisabgabe.',
          capabilities: [
            'Physische Positionsinduzierung ohne chemische Bindungsverluste',
            'Adaptiver Strömungswiderstand des Trägerpartikels',
            'Subzelluläre Dynamikverfolgung in Echtzeit'
          ],
          specs: [
            { name: 'Partikeldurchmesser', value: '15.4 nm ± 0.8 nm' },
            { name: 'Kapselungseffizienz', value: '≥ 94.2%' },
            { name: 'Freisetzungszeit', value: '< Mikrosekundenbereich' }
          ],
          problem: 'Herkömmliche Infusionen schädigen umliegendes Gewebe und erleiden vorzeitigen Abbau im Blutstrom.',
          approach: 'Der Vector-X10 reagiert auf lokalisierte Energieimpulse und gibt Wirkstoffe selektiv erst am Erkrankungsherd frei.'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: 'Kryogener Quanten-Molekularscanner',
          desc: 'Zerstörungsfreie Zell-Tomographie auf Quantenebene zur simultanen Messung metabolischer Fluktuationen.',
          capabilities: [
            'Raman-Lichtstreuung ohne chemische Färbung',
            'Präzise Rekonstruktion tiefer Gewebeschichten',
            'Digitale Visualisierung epigenetischer Muster'
          ],
          specs: [
            { name: 'Laterale Auflösung', value: '4.2 Å (Angström-Präzision)' },
            { name: 'Abtastfrequenz', value: '< 2.4 fs' },
            { name: 'Gewebetiefe', value: 'Bis zu 800 μm in-vivo' }
          ],
          problem: 'Präparationen für die Färbeoptik töten gesunde Kulturen ab und verzerren Live-Beobachtungen.',
          approach: 'Mithilfe von Quanteninterferenz filtriert der Chronos-Spectrum spontane Streuungen und visualisiert Gewebe unverfälscht.'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: 'Biokompatible synaptische Schnittstelle',
          desc: 'Hochflexible Kohlenstoff-Mikroelektroden zur regenerativen Kopplung und Echtzeit-Dekodierung neuronaler Potenziale.',
          capabilities: [
            'Beschichtung mit biokompatibler Hydrogel-Polymerschicht',
            '2048-Kanal-Sensormatrix zur präzisen Signalverteilung',
            'Integrierte Edge-KI zur Signalübersetzung'
          ],
          specs: [
            { name: 'Leitfähigkeit', value: '1.2 × 10^4 S/m' },
            { name: 'Potential-Rauschen', value: '< 10 μV' },
            { name: 'Trägerdicke', value: '3.5 μm (Ultradünn)' }
          ],
          problem: 'Starr verdrahtete Implantate führen zu Immunreaktionen, Gewebe-Entzündungen und raschem Signalverlust.',
          approach: 'Synapse-Link wird durch biomimetische Oberflächen direkt von Astrozyten umgeben, wodurch dauerhafte Ströme fließen.'
        }
      ]
    },
    contact: {
      badge: 'DIREKTVERBINDUNG',
      title: 'Treten Sie mit AufMed in Kontakt',
      subtitle: 'Wir beraten forschende Kliniken, Designpartner und strategische Kapitalgeber auf globalem Niveau.',
      hqTitle: 'Standorte der Exzellenz',
      hqAddress: 'München Core: Leopoldstraße 244, 80807 München, Deutschland\nShanghai Studio: No. 200 Bingjiang Blvd, Shanghai, China',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: 'Name',
      formOrg: 'Institution / Labor',
      formInquiryType: 'Anliegen',
      formInquiryOptions: [
        'Gemeinsame akademische Forschung',
        'Klinische Erprobung unserer Geräte',
        'Kooperation im Bereich MedTech-Design',
        'Investitionen und Beteiligungen'
      ],
      formMessage: 'Kurze Beschreibung Ihrer Ziele',
      formSubmit: 'Verschlüsselt übermitteln',
      successMessage: 'Ihre Anfrage wurde verschlüsselt an unseren Vorstand übermittelt. Ihr persönlicher Ansprechpartner meldet sich binnen 24 Stunden.',
      placeholderName: 'z.B. Dr. Michael Weber',
      placeholderOrg: 'z.B. Max-Planck-Institut',
      placeholderMessage: 'Bitte umreißen Sie kurz Ihre Forschungs- und Kooperationsziele.'
    },
    footer: {
      tagline: 'Die Umprogrammierung biologischer Sequenzen ist unsere Kunst.',
      legal: 'AufMed Medical Technology Group GmbH © Alle Rechte vorbehalten.',
      allRightsReserved: 'Zugelassen für klinische Forschungsnetzwerke.',
      designerIdentity: 'Konzipiert durch AufMed Design Studio // AI & Brand Lab'
    }
  },
  fr: {
    dir: 'ltr',
    nav: {
      home: 'Accueil',
      about: 'Groupe',
      products: 'Systèmes',
      contact: 'Contact',
    },
    hero: {
      badge: 'CONVERGENCE DES BIOPHYSIQUES ET DU CALCUL',
      title: 'La Physique de Précision',
      highlight: 'Redéfinit les Limites du Vivant',
      subtitle: 'Le groupe technologique médical AufMed conçoit des vecteurs moléculaires actifs, de l’imagerie subcellulaire d’extrême résolution et des jumeaux numériques cliniques.',
      ctaPrimary: 'Consulter nos Systèmes',
      ctaSecondary: 'Chercheur Conseil',
    },
    intro: {
      badge: 'À PROPOS D’AUFMED',
      title: 'Fusion Biophysique & Clarté Industrielle',
      subtitle: 'La perfection médicale se réalise dans l’adéquation de l’exactitude mathématique et de la rigueur plastique.',
      paragraphs: [
        'Issu de laboratoires de biophysique européens de premier plan, AufMed applique le contrôle spatial atomique aux besoins oncologiques et neurologiques de pointe.',
        'Nos équipes de designers, d’ingénieurs et de cliniciens structurent des solutions matérielles au design minimal, réduisant la distraction cognitive et augmentant la précision diagnostique.'
      ],
      statsTitle: 'Activité de Recherche',
      stats: [
        { value: '12', label: 'Centres Nationaux' },
        { value: '420+', label: 'Brevets Déposés' },
        { value: '1.2nm', label: 'Précision du Ciblage' },
        { value: '99.4%', label: 'Prévisibilité Machine' }
      ],
      milestonesTitle: 'Parcours d’Innovation',
      milestones: [
        { year: '2020', title: 'Fondation', desc: 'Instigation des pôles de recherche de Berlin et de Shanghai.' },
        { year: '2022', title: 'Limite Nano', desc: 'Première mondiale de moteurs moléculaires lipidiques acoustiques.' },
        { year: '2024', title: 'AetherBio Core', desc: 'Lancement de notre IA générative d’agencement de chaines peptidiques.' },
        { year: '2026', title: 'Sacre Esthétique', desc: 'Notre interface HMI est couronnée pour sa pureté fonctionnelle.' }
      ]
    },
    products: {
      badge: 'TECHNOLOGIES SÉLECTIONNÉES',
      title: 'Systèmes Déterminants de Thérapie Ciblée',
      subtitle: 'Nous transformons des principes de diffusion thermique et atomique en interfaces d’une robustesse sereine.',
      viewDetails: 'Données & Fiches techniques',
      capabilitiesTitle: 'Fonctionnalités Clés',
      specsTitle: 'Paramètres Physiques',
      problemTitle: 'Obstacle Clinique Éliminé',
      approachTitle: 'Solution Proposée',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: 'Nanotransporteur Intracellulaire Actif',
          desc: 'Capsule lipidique activée par micro-impulsions radiofréquence, s’ouvrant exclusivement aux abords immédiats des biomarqueurs pathogènes.',
          capabilities: [
            'Optimisation géométrique réduisant la capture hépatique',
            'Ouverture sans réaction exothermique nocive',
            'Mesure de bio-impédance intracellulaire dynamique'
          ],
          specs: [
            { name: 'Diamètre Moyen', value: '15.4 nm ± 0.8 nm' },
            { name: 'Encapsulation active', value: '≥ 94.2%' },
            { name: 'Latence du relargage', value: 'Contrôlable à la microseconde' }
          ],
          problem: 'Les thérapies chimiques classiques endommagent les tissus périphériques sains, occasionnant de lourds effets systémiques.',
          approach: 'La vectorisation active du Vector-X10 utilise une modulation vibratoire spécifique pour franchir les barrières membranaires sans altérer les cellules saines.'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: 'Scanner Quantique Subcellulaire 3D',
          desc: 'Imagerie spectrale Raman auto-centrée de haute sensibilité, générant des captures de cellules vivantes sans agent d’étalement toxique.',
          capabilities: [
            'Excitation laser femtoseconde ultra-courte non ionisante',
            'Correction d’anomalie optique par modélisation d’onde',
            'Modélisation en jumeau numérique 3D en temps réel'
          ],
          specs: [
            { name: 'Résolution Latérale', value: '4.2 Å (Précision Angström)' },
            { name: 'Temps d’Intégration', value: '< 2.4 fs' },
            { name: 'Pénétration Tissulaire', value: 'Jusqu’à 800 μm in-vivo' }
          ],
          problem: 'La microscopie de coloration détruit la configuration spatiale naturelle de l’organelle, faussant l’observation clinique.',
          approach: 'Chronos-Spectrum capte directement les transitions d’énergie moléculaire propres, restituant une cinématique ultra-fidèle sans coloration.'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: 'Matrice d’Électrodes Synaptiques Souples',
          desc: 'Interface neuronale directe en graphène polymère pour la réhabilitation sensori-motrice de précision supérieure.',
          capabilities: [
            'Structure poreuse permettant l’irrigation neuronale',
            '2048 micro-points de captation de gradients membranaires',
            'Système de filtrage du bruit de potentiel à l’échelle locale'
          ],
          specs: [
            { name: 'Conductivité Matricielle', value: '1.2 × 10^4 S/m' },
            { name: 'Tension de Seuil', value: '< 10 μV' },
            { name: 'Épaisseur du Substrat', value: '3.5 μm (Ultra-fine)' }
          ],
          problem: 'Les broches neuronales métalliques rigides créent une réaction immunitaire de rejet et une perte rapide de la liaison.',
          approach: 'Synapse-Link utilise un support flexible favorisant l’intégration symbiotique, maintenant un échange stable pendant plusieurs cycles.'
        }
      ]
    },
    contact: {
      badge: 'LIGNE DIRECTE',
      title: 'Formuler une Demande Initiateur',
      subtitle: 'Nos ingénieurs orientent l’application thérapeutique et le codéveloppement esthétique de vos composants médicaux.',
      hqTitle: 'Adresses des Centres',
      hqAddress: 'Siège Munich: Leopoldstraße 244, 80807 München, Allemagne\nAtelier Shanghai: No. 200 Bingjiang Blvd, Shanghai, Chine',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: 'Civilité & Nom',
      formOrg: 'Établissement / Laboratoire',
      formInquiryType: 'Canal Thématique',
      formInquiryOptions: [
        'Programme Académique & R&D Commune',
        'Autorisation Temporaire d’Utilisation',
        'Partenariat Design & Ergonomie Médicale',
        'Prises de Participation Régulées'
      ],
      formMessage: 'Description Synthétique du Projet',
      formSubmit: 'Émettre la Requête Chiffrée',
      successMessage: 'Votre requête a été encryptée et transmise au comité AufMed. Notre équipe opérationnelle se mettra en contact sous 24h.',
      placeholderName: 'ex. Dr. Jeanne Mathieu',
      placeholderOrg: 'ex. Inserm UMR302',
      placeholderMessage: 'Précisez sommairement le marqueur ou l’organe ciblé par vos travaux actuels.'
    },
    footer: {
      tagline: 'L’agencement du vivant est notre art.',
      legal: 'AufMed Medical Technology Group GmbH © Tous droits réservés.',
      allRightsReserved: 'Homologué pour réseaux de recherche clinique avancés.',
      designerIdentity: 'Design par AufMed Studio // AI & Brand Creative Division'
    }
  },
  ja: {
    dir: 'ltr',
    nav: {
      home: 'ホーム',
      about: '企業紹介',
      products: '製品・システム',
      contact: 'お問い合わせ',
    },
    hero: {
      badge: 'バイオフィジクスと計算機科学の統合',
      title: '超精密物理学と細胞インテリジェンス',
      highlight: '生命医療テクノロジーを再定義する',
      subtitle: 'AufMedメディカルテクノロジーグループは、分子標的輸送、超高解像度細胞診断、量子生体シミュレーションの統合により、先端臨床に新たなパラダイムを提示します。',
      ctaPrimary: 'フロンティア製品を探る',
      ctaSecondary: '主任研究員に連絡',
    },
    intro: {
      badge: 'ABOUT AUFMED',
      title: '分子物理学と先端デザインの調和',
      subtitle: '「最先端の医療技術は、純粋な自然科学の真理と極限の美学が結実した姿である」という信念。',
      paragraphs: [
        'AufMedメディカルテクノロジーグループは、欧州の先端物理研究所から発祥し、原子レベルの物理操作技術と生体計算をシームレスに結合する革新的な医療システムを開発しています。',
        'ビジュアルデザイナー、AIアーキテクト、そしてブランディング専門家が共同で立ち上げた異色の技術拠点として、医学的な厳密性を守りつつ、構造主義に基づく美学をインターフェースデザインに反映しています。'
      ],
      statsTitle: 'グローバル研究指標',
      stats: [
        { value: '12', label: 'グローバル共同開発ハブ' },
        { value: '420+', label: 'バイオ・物理・電子特許数' },
        { value: '1.2nm', label: '分子標的極限輸送精度' },
        { value: '99.4%', label: '生体タンパクフォールディング予測' }
      ],
      milestonesTitle: '進化の軌跡',
      milestones: [
        { year: '2020', title: '共同設立', desc: 'ベルリンと上海にバイオフィジクス多相解析研究所を開設。' },
        { year: '2022', title: '1nmの壁を突破', desc: '原子共鳴バイオモーター搭載キャリアを実証。' },
        { year: '2024', title: 'AetherBio AI導入', desc: '機械学習を用いた自己組織化アミノ酸動力学エンジンを発表。' },
        { year: '2026', title: '世界的な受賞', desc: '新世代の臨床UIシステムが権威あるデザインアワードにて最高賞を受賞。' }
      ]
    },
    products: {
      badge: 'PRODUCT PORTFOLIO',
      title: '細胞への超精密干渉をもたらす製品群',
      subtitle: '高度な量子反応を、美しく直感的、かつ極めて機能的な構造体にパッケージ化しています。',
      viewDetails: '仕様と仕様書データ',
      capabilitiesTitle: '特筆すべき機能',
      specsTitle: '学術仕様パラメータ',
      problemTitle: '既存技術の課題',
      approachTitle: 'AufMedのアプローチ',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: 'アクティブ分子標的型ナノキャリア細胞輸送体',
          desc: '電磁波誘導により細胞膜の活性相変化を瞬時に誘発し、健全な組織を傷つけることなく薬剤を放出する知能脂質体ナノキャリア。',
          capabilities: [
            '物理場による局所共鳴コントロール、親和性化学物質不要',
            '流動流体抵抗に適応するシェル・ヘキサゴナル変形素材',
            'サブセルグリッドインピーダンスリアルタイム計測内蔵'
          ],
          specs: [
            { name: '平均粒径', value: '15.4 nm ± 0.8 nm' },
            { name: '封入効率', value: '≥ 94.2%' },
            { name: 'トリガー遅延時間', value: 'ミリ秒単位プログラマブル' }
          ],
          problem: '従来の非標的型薬物送達は、不要な全身毒性を誘発し、細胞核へ届く前にほとんどが体内分解されてしまいます。',
          approach: 'Vector-X10は、外部の低周波物理パルスを入力することで作用点においてのみ相転移し、ほぼ100％のターゲティングを実現します。'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: '亜細胞生体内3次元ホログラフィック量子スキャナー',
          desc: '非侵襲的かつ染色フリーで、細胞内各種オルガネラの動態やメチル化動態をナノミクロン秒単位で可視化する超高解像度計測装置。',
          capabilities: [
            'フェムト秒レーザー散乱に基づく無損傷コヒーレントイメージング',
            '多重散乱誤差を相殺する高速ウェーブフロント補正システム',
            '生体デジタルツインによるリアルタイム解析描画'
          ],
          specs: [
            { name: '水平解像度', value: '4.2 Å (オングストローム精密)' },
            { name: 'サンプリング間隔', value: '< 2.4 fs' },
            { name: '非破壊観測深度', value: '最大 800 μm (生体内深部可能)' }
          ],
          problem: '既存の蛍光標識法では、観測光自体が細胞に著しい光毒性変性を与え、自然な長期動態追跡を困難にしていました。',
          approach: 'Chronos-Spectrumは、量子コヒーレンス微弱計測法を用いて散乱スペクトルを数学的に分解、生身の細胞ドラマを色鮮やかにシネマティック表示します。'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: '超高密度フレキシブル神経接合バイオグリッド',
          desc: '極小の傷を自己治癒するカーボンナノチューブハイブリッドフィルムを使用し、人間の高次元運動中心と完全結合・翻訳する親密な神経インターフェース。',
          capabilities: [
            '神経細胞への親和性が高い水和ゲル電極シース',
            '2048チャネル超低インピーダンス可変グリッド',
            'エッジコンピューティングによるリアルタイム脳波・動作デコーダー'
          ],
          specs: [
            { name: '導電率行列', value: '1.2 × 10^4 S/m' },
            { name: 'バイオ誘電雑音', value: '< 10 μV' },
            { name: 'フイルム厚み', value: '3.5 μm (超極薄)' }
          ],
          problem: '金属や硬質プラスチックを用いた電極は強烈な免疫拒絶を引き起こし、やがて周囲がグリア膠組織で覆われ信号が恒久遮断されます。',
          approach: 'Synapse-Linkは擬似胚芽構造を誘発。周囲のグリア細胞と融合共生することで、生体の一部として半永久的な信号結合を可能にしました。'
        }
      ]
    },
    contact: {
      badge: 'CONTACT CHANNELS',
      title: 'AufMed 開発エンジニアとダイレクトコンタクト',
      subtitle: '共同研究、特殊臨床配備、また先端医療テクノロジーにおける体験・ビジュアルブランドデザインの受託。',
      hqTitle: '卓越統合センター拠点',
      hqAddress: 'ミュンヘン開発院: Leopoldstraße 244, 80807 München, Germany\n上海先端スタジオ: 上海市浦東新区陸家嘴江大道200号',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: 'お名前',
      formOrg: '所属機関 / 大学研究室',
      formInquiryType: 'お問い合わせ区分',
      formInquiryOptions: [
        '学術・研究機関による共同基礎開発',
        '先端臨床テスト機器および認可プログラム応用',
        '高科技プロダクト美学およびUIコンサルティング',
        '戦略的アライアンスおよび投資連携'
      ],
      formMessage: '研究概要・協業目標の記述',
      formSubmit: '暗号化通信で送信',
      successMessage: '送信が完了しました。ご入力内容はエンドツーエンドで暗号化され、AufMed グローバルパートナシップ部門に届けられます。24時間以内に専門担当者より折り返しご連絡いたします。',
      placeholderName: '例: 山田 花子 博士',
      placeholderOrg: '例: 先端生物研究所 / 某医療大学センター',
      placeholderMessage: '現在進めていられる研究分野、および弊社システムのどの機能を用いて加速を狙われているか簡潔にお知らせください。'
    },
    footer: {
      tagline: '生命をコード化し、美しく物質世界に落とし込む。',
      legal: 'AufMed Medical Technology Group GmbH © All rights reserved.',
      allRightsReserved: '学術研究・特定臨床プログラムの仕様承認。',
      designerIdentity: 'Designed by AufMed Studio // AI & Brand Dev'
    }
  },
  ko: {
    dir: 'ltr',
    nav: {
      home: '홈',
      about: '그룹 소개',
      products: '최첨단 제품',
      contact: '문의하기',
    },
    hero: {
      badge: '생물 물리학과 디지털 컴퓨팅의 융합',
      title: '초정밀 물리 공학과 세포 인공지능',
      highlight: '의료 기술 생태계를 재정의하다',
      subtitle: 'AufMed는 분자 표적 전달, 초고해상도 나노 영상 및 양자 바이오 시뮬레이션을 연구하여 글로벌 프리미엄 연구 기관에 새로운 패러다임을 제안합니다.',
      ctaPrimary: '시스템 자세히 보기',
      ctaSecondary: '연구진과 직접 통화',
    },
    intro: {
      badge: 'ABOUT AUFMED',
      title: '물리학적 탐구와 감각적 절제미의 수렴',
      subtitle: '우리는 믿습니다: 가장 진일보한 의료 기술은 순수 과학적 법칙과 극한의 조형미가 완벽하게 일치할 때 구현됩니다.',
      paragraphs: [
        '유럽 바이오피직스 핵심 연구실에서 출발한 AufMed는 원자 수준의 유도 물리학과 생체 계산 기법을 융합하여 질환을 선제적으로 감지하고 구조화된 치유 에너지를 전달합니다.',
        '특히 비주얼 디자이너, AI 엔지니어, 브랜드 아키텍트들이 창립한 글로벌 크리에이티브 허브로서 의료 기기에 구조주의적 조형 미학을 접목한 HMI를 독점 개발하고 있습니다.'
      ],
      statsTitle: '글로벌 연구 성과 지수',
      stats: [
        { value: '12', label: '글로벌 연구 허브' },
        { value: '420+', label: '원천 기술 특허' },
        { value: '1.2nm', label: '최대 전달 표적 오차' },
        { value: '99.4%', label: '단백질 접힘 시뮬레이션 일치도' }
      ],
      milestonesTitle: '진화의 여정',
      milestones: [
        { year: '2020', title: '연합 공동 설립', desc: '베를린과 상하이에 생물 고해상도 연구 센터 동시 출범.' },
        { year: '2022', title: '나노 장벽 극복', desc: '초음파 분자 모터를 활용한 첫 능동형 나노 입자 전달 데모 성공.' },
        { year: '2024', title: 'AetherBio AI 코어', desc: '다차원 상태 변화 예측 다중 모달 신경망 릴리즈.' },
        { year: '2026', title: '최고 디자인상 석권', desc: '메디컬 제어 시스템 UI가 최우수 인터랙션 디자인 수상을 거머쥠.' }
      ]
    },
    products: {
      badge: 'PRODUCT PORTFOLIO',
      title: '치밀한 지능형 바이오 간섭 시스템',
      subtitle: '실험적 데이터를 우아하고 기능적인 최상급 인터페이스 하드웨어에 직교시켰습니다.',
      viewDetails: '사양 및 리포트 파일',
      capabilitiesTitle: '핵심 기능 정의',
      specsTitle: '학술적 특성 스펙',
      problemTitle: '기존의 한계와 미충족 수요',
      approachTitle: 'AufMed의 독창적 해결법',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: '전기자기학 유도 능동 분자 캐리어 시스템',
          desc: '주파수 특이 반응 세포막 붕괴 메커니즘을 적용하여 주변 조직 손상 없이 완전 타겟팅 방출을 주도하는 리포좀 나노 캐리어.',
          capabilities: [
            '물리적 외장에 의한 제어, 대사성 리간드 소모에 따른 감쇠 없음',
            '다변 혈류 유체 저항에 반응하는 자기 성형 헥사 기판 기반 외막',
            '실시간 내부 임피던스 미세 구획 검지 트래킹'
          ],
          specs: [
            { name: '평균 구경 크기', value: '15.4 nm ± 0.8 nm' },
            { name: '약물 봉입률', value: '≥ 94.2%' },
            { name: '방출 작동 시간', value: '마이크로초 제어 가능' }
          ],
          problem: '기존 약물 전달 기술은 표적 이외 영역으로 독성이 누수되어 전신 쇠약을 일으키고 정작 병변에서의 효율이 떨어집니다.',
          approach: 'Vector-X10은 외부 무해 파동 자극을 수용하고, 정상 세포 영역을 통과할 때는 정적 성질을 띠다 표적 지점에서만 신속 상전이합니다.'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: '초고해상도 양자 3D 세포 구조 스캐너',
          desc: '특수 염색체 처리 없이 자발적 라만 융기 파동을 수학적으로 해석해 세포 깊은 구조를 촬영하는 무염색 라이브 스캔 솔루션.',
          capabilities: [
            '단위 세포 열 변형 방지 펨토초 레이저 비파괴 측정 기술',
            '생체 조직 가시광 산란 극복 다차원 보정 알고리즘',
            'Epigenetic 실시간 디지털 복제 가상 매핑'
          ],
          specs: [
            { name: '수평 해상도', value: '4.2 Å (앙스트롬 정밀도)' },
            { name: '신호 획득 단위', value: '< 2.4 fs' },
            { name: '투과 심도', value: '최대 800 μm' }
          ],
          problem: '형광 염색 및 면역 화학 검사는 세포 생존성을 훼손시켜 긴 반응 분석 및 자연 상태 모니터링이 불가능합니다.',
          approach: 'Chronos-Spectrum은 미세 양자 중첩 상호작용 분석 시스템을 가동해 생세포를 무수정 시네마틱으로 선명하게 재구성합니다.'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: '뇌 신경 기능 재건 카본 바이오 결합 전극',
          desc: '기계적 성능의 극대화를 꾀하는 특수 전도 신소재를 세포 접합면과 정합시켜 신경 연접 신호를 번역하는 뇌-기계 결합 장치.',
          capabilities: [
            '세포 부착성이 극대화된 유연성 고분자 매트릭스 지지층',
            '2048개 다접점 배열 초저 분극 고전도성 전극 구성',
            '에지 단말 장착 고성능 신호 패턴 고속 딥러닝 디코더'
          ],
          specs: [
            { name: '면 전도도 배열', value: '1.2 × 10^4 S/m' },
            { name: '배경 전위 잡음', value: '< 10 μV' },
            { name: '지지층 두께', value: '3.5 μm (초박막)' }
          ],
          problem: '딱딱한 고정식 전극은 영구적 이물 저항을 촉발해 성상교세포 흉터를 형성하여 정보 전달률이 급락합니다.',
          approach: 'Synapse-Link는 세포 유사 지형구조 조형을 통해 아교세포가 외막을 스스로 포용하도록 가이드하여 자연스러운 생체 직교가 가능합니다.'
        }
      ]
    },
    contact: {
      badge: 'SECURE LINK',
      title: 'AufMed의 테크니컬 크리에이터와 대화',
      subtitle: '맞춤형 공동 파트너십 구축, 첨단 사양 장비의 임상 승인 연구, 고도화된 의료 브랜딩 및 산업 디자인 공동 프로젝트 시너지.',
      hqTitle: '글로벌 엔지니어링 허브',
      hqAddress: '뮌헨 파트너십 허브: Leopoldstraße 244, 80807 München, Germany\n상하이 전면 디자인 스튜디오: No. 200 Bingjiang Blvd, Shanghai, China',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: '이름 및 직함',
      formOrg: '소속 기관 및 연구소 명칭',
      formInquiryType: '파트너십 분류',
      formInquiryOptions: [
        '학술 연구 기관 바이오 컴퓨팅 공동 R&D',
        '의료원 임상 시제품 실증 지원',
        '디자인 솔루션 및 브랜드 시각 가이드라인 개발 협업',
        '전략 지분 기금 운용 및 자본 결합'
      ],
      formMessage: '연구 개요 및 협업 목표',
      formSubmit: '암호화 채널로 요청',
      successMessage: '귀하의 전문적 요청사항이 전 구간 암호화 처리되어 아시아/유럽 커뮤니케이션 연구 담당자에게 이관되었습니다. 24시간 내에 후속 미팅을 조율하기 위해 개별 연락드리겠습니다.',
      placeholderName: '예: 김윤아 박사',
      placeholderOrg: '예: 카이스트 바이오소재 연구단',
      placeholderMessage: '진행 중인 의약/생체 연구 목적 및 아우프메드 장치의 어떤 기능 결합을 희망하시는지 약술해 주십시오.'
    },
    footer: {
      tagline: '생체 시퀀스를 조각하고 물리라는 필연을 직교시킨다.',
      legal: 'AufMed Medical Technology Group GmbH © All rights reserved.',
      allRightsReserved: '실험 사용용도 및 지정 임상연구 규범 승인필.',
      designerIdentity: 'Designed by AufMed Studio // AI & Brand Creative Division'
    }
  },
  es: {
    dir: 'ltr',
    nav: {
      home: 'Inicio',
      about: 'Organización',
      products: 'Soluciones',
      contact: 'Contacto',
    },
    hero: {
      badge: 'CONVERGENCIA DE BIOFÍSICA Y COMPUTACIÓN',
      title: 'Con Física de Alta Precisión',
      highlight: 'Rediseñando los Límites del Cuidado de la Vida',
      subtitle: 'Grupo de tecnología médica especializada en transporte molecular dirigido de alta afinidad, imágenes subcelulares nanométricas y simulaciones de dinámica cuántica.',
      ctaPrimary: 'Descubrir Sistemas',
      ctaSecondary: 'Conversar con un Investigador',
    },
    intro: {
      badge: 'ACERCA DE AUFMED',
      title: 'Donde la Física de Partículas se Cruza con el Diseño Estructural',
      subtitle: 'Creemos: El grado más alto de la invención médica se manifiesta en la reconcilicación de la verdad objetiva y la suprema sintonía formal.',
      paragraphs: [
        'Con origen en laboratorios europeos de física biológica de primer orden, AufMed desarrolla arquitecturas dirigidas al control celular microscópico inteligente mediante interfaces bióricas unificadas.',
        'Imaginado por diseñadores visuales, académicos de marca y doctores en computación, optimizamos los parámetros operacionales de los equipos médicos al deshacernos de las distracciones e implementar un lenguaje estricto y sobrio.'
      ],
      statsTitle: 'Métricas de Investigación',
      stats: [
        { value: '12', label: 'Centros Globales R&D' },
        { value: '420+', label: 'Patentes Moleculares' },
        { value: '1.2nm', label: 'Margen de Desviación' },
        { value: '99.4%', label: 'Concordancia en Dinámica' }
      ],
      milestonesTitle: 'Evolución Histórica',
      milestones: [
        { year: '2020', title: 'Fundación del Consorcio', desc: 'Apertura coordinada de laboratorios en Berlín y Shanghái.' },
        { year: '2022', title: 'Dimensión Sub-Nano', desc: 'Validación del vector hidrodinámico impulsado por acústica celular.' },
        { year: '2024', title: 'AetherBio AI Core', desc: 'Implementación del predictor de plegamientos con red convolucional cuántica.' },
        { year: '2026', title: 'Prestigio en Diseño', desc: 'Nuestra suite visual HMI recibe el galardón supremo de diseño industrial.' }
      ]
    },
    products: {
      badge: 'SISTEMAS DESTACADOS',
      title: 'Intervención de Precisión a Escala Subcelular',
      subtitle: 'Materializamos dinámicas microfísicas en herramientas sencillas de usar y de insuperable sofisticación.',
      viewDetails: 'Parámetros y Especificaciones',
      capabilitiesTitle: 'Atributos Clave',
      specsTitle: 'Especificaciones Académicas',
      problemTitle: 'Desafío Abordado',
      approachTitle: 'Metodología AufMed',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: 'Transportor de Nanopartículas Inteligentes',
          desc: 'Nanocápsulas lipídicas guiadas por inducción de campos magnéticos para la descarga no destructiva de activos terapéuticos específicos.',
          capabilities: [
            'Guiado espacial sin pérdida de afinidades químicas',
            'Absorción controlada mediante coeficiente elástico termorregulado',
            'Control microscópico continuo de impedancia tisular'
          ],
          specs: [
            { name: 'Diámetro Medio', value: '15.4 nm ± 0.8 nm' },
            { name: 'Eficiencia', value: '≥ 94.2%' },
            { name: 'Retraso de Activación', value: 'Control a escala de microsegundos' }
          ],
          problem: 'Los métodos sistémicos corrientes no discriminan los tejidos sanos, induciendo toxicidad masiva y colapso celular prematuro.',
          approach: 'Vector-X10 se mantiene inerte durante la circulación y responde con precisión atómica a pulsos acústicos externos focalizados.'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: 'Escáner Epigenético Holográfico Multiespectral',
          desc: 'Visualizador cuántico no invasivo de alta velocidad, libre de tinciones tóxicas, para el seguimiento molecular en tiempo real.',
          capabilities: [
            'Mapeo espectral no destructivo basado en láser de femtosegundos',
            'Corrección de interferencia mediante espectrometría reconstructiva',
            'Simulación instantánea con Gemelo Digital de dinámicas celulares'
          ],
          specs: [
            { name: 'Resolución Lateral', value: '4.2 Å (Presicón de Angstrom)' },
            { name: 'Retraso de Muestra', value: '< 2.4 fs' },
            { name: 'Penetración Óptica', value: 'Hasta 800 μm' }
          ],
          problem: 'Los tintes fotoactivos dañan celularmente las muestras cultivadas, entorpeciendo el estudio dinámico interactivo.',
          approach: 'Chronos-Spectrum capta la dispersión Raman pura y descodifica la señal a través de un algoritmo de correlación de interferencias.'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: 'Matriz Flexible de Polímeros Sinápticos',
          desc: 'Interfaz neuronal en película delgada de carbono biocompatible, diseñada para la adquisición bidireccional estable de impulsos neuronales.',
          capabilities: [
            'Soporte de poros micrométricos que permite la respiración glial',
            '2048 puntos de medición de gradientes iónicos adaptativos',
            'Unidad de descodificación de patrones integrada en chip de silicio'
          ],
          specs: [
            { name: 'Conductividad Eléctrica', value: '1.2 × 10^4 S/m' },
            { name: 'Ruido del Potencial', value: '< 10 μV' },
            { name: 'Grosor de la Película', value: '3.5 μm' }
          ],
          problem: 'Los electrodos corticales convencionales causan cicatrización glial severa y pérdida inmediata de la conductividad.',
          approach: 'Synapse-Link emplea un diseño biointeractivo que estimula una microcolaboración estable con los astrocitos biológicos.'
        }
      ]
    },
    contact: {
      badge: 'CONEXIÓN ENCRIPTADA',
      title: 'Póngase en Contacto con AufMed',
      subtitle: 'Ofrecemos consultorías de diseño biomédico, implementación de pruebas y codiseño estratégico de marcas tecnológicas.',
      hqTitle: 'Sedes Operativas Globales',
      hqAddress: 'Sede Múnich: Leopoldstraße 244, 80807 München, Alemania\nEstudio Shanghái: No. 200 Bingjiang Blvd, Shanghái, China',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: 'Nombre Completo',
      formOrg: 'Institución u Organización',
      formInquiryType: 'Área de Interés',
      formInquiryOptions: [
        'Desarrollo Académico Grupal (R&D)',
        'Sometimiento de Ensayos Clínicos',
        'Codiseño de Identidades y Ergonomía Visual',
        'Socios de Inversión Estratégica'
      ],
      formMessage: 'Resumen o Propuesta de Cooperación',
      formSubmit: 'Enviar Mensaje Encriptado',
      successMessage: 'Su mensaje ha sido debidamente procesado con cifrado asimétrico. Un consultor científico se pondrá en contacto dentro de las próximas 24 horas.',
      placeholderName: 'ej. Dra. Luciana Solís',
      placeholderOrg: 'ej. Laboratorio de Neurobiología Avanzada',
      placeholderMessage: 'Breve descripción del alcance científico y los requerimientos del sistema médico que desea coordinar con AufMed.'
    },
    footer: {
      tagline: 'Modelar las secuencias de la vida con la elegancia de la física.',
      legal: 'AufMed Medical Technology Group GmbH © Todos los derechos reservados.',
      allRightsReserved: 'Aprobado para uso clínico investigacional y protocolos médicos.',
      designerIdentity: 'Diseñado por el Estudio Visual de AufMed // AI & Brand Creative Division'
    }
  },
  ar: {
    dir: 'rtl',
    nav: {
      home: 'الشاشة الرئيسية',
      about: 'مقدمة عن المجموعة',
      products: 'المنتجات المختارة',
      contact: 'اتصل بنا',
    },
    hero: {
      badge: 'تلاقي الفيزياء الحيوية والحوسبة الرقمية',
      title: 'بفيزياء فائقة الدقة',
      highlight: 'نعيد تشكيل حدود تكنولوجيا الحياة والطب',
      subtitle: 'تركز مجموعة AufMed للتقنيات الطبية على الإيصال الجزيئي الموجه، والتشخيص الخلوي فائق الوضوح، والمحاكاة الكمية للأنظمة الحيوية، لتقديم معايير دقيقة للمؤسسات الرائدة عالميًا.',
      ctaPrimary: 'استكشاف الأنظمة الرائدة',
      ctaSecondary: 'تحدث مع أحد الباحثين',
    },
    intro: {
      badge: 'حول AUFMED',
      title: 'دمج الفيزياء الجزيئية والتصميم الصناعي المتطلع',
      subtitle: 'نحن نؤمن بعمق: أن التكنولوجيا الطبية الأكثر رقيًا هي بطبيعتها التموج المطلق بين الحقيقة العلمية والجمال الإنشائي.',
      paragraphs: [
        'نشأت مجموعة AufMed للتقنيات الطبية من المختبرات الأوروبية المتقدمة لتقود التقارب بين تكنولوجيا التلاعب الفيزيائي الذري والحوسبة الخلوية الدقيقة.',
        'كصرح تقني تم تأسيسه بشراكة بين مصممي المرئيات، ومهندسي الذكاء الاصطناعي، وخبراء العلامات التجارية، تلتزم AufMed بالصرامة الطبية المطلقة، مع دمج فلسفة الجماليات البنائية في واجهات التحكم والتفاعل البشري.'
      ],
      statsTitle: 'مؤشرات البحوث العالمية',
      stats: [
        { value: '12', label: 'مراكز بحوث عالمية مشتركة' },
        { value: '420+', label: 'براءات اختراع أساسية وحيوية' },
        { value: '1.2nm', label: 'دقة التوجيه الجزيئي القصوى' },
        { value: '99.4%', label: 'تطابق محاكاة طيات البروتين' }
      ],
      milestonesTitle: 'محطات التطور',
      milestones: [
        { year: '2020', title: 'التأسيس المشترك', desc: 'افتتاح معاهد أبحاث الفيزياء الحيوية متعددة الأنماط في برلين وشنغهاي بالتزامن.' },
        { year: '2022', title: 'تخطي حاجز النانومتر', desc: 'إثبات نجاح أول ناقل ذري مزود بمحرك جزيئي صوتي.' },
        { year: '2024', title: 'محرك أثير بيو للذكاء الاصطناعي', desc: 'إطلاق نموذج التنبؤ بالاضطرابات الديناميكية الذرية لطي البروتين.' },
        { year: '2026', title: 'اجتماع الفن والطب', desc: 'حصول واجهة التحكم الطبية للجيل الجديد على الجائزة الكبرى للتصميم الصناعي.' }
      ]
    },
    products: {
      badge: 'مجموعة النظم المختارة',
      title: 'مجموعات تكنولوجية تعيد صياغة التدخل العلاجي',
      subtitle: 'تقوم AufMed بتغليف العمليات الحيوية والكمومية المعقدة في هياكل برمجية متميزة وعالية السهولة والنقاء.',
      viewDetails: 'المواصفات والبيانات التقنية',
      capabilitiesTitle: 'مميزات وقدرات النظام',
      specsTitle: 'المعايير التقنية الأكاديمية',
      problemTitle: 'التحديات الطبية والاحتياجات الحالية',
      approachTitle: 'حلول AufMed المبتكرة',
      items: [
        {
          id: 'molecular-delivery',
          name: 'AufMed Vector-X10',
          category: 'نظام النقل الجزيئي النشط الموجه',
          desc: 'ناقلات جزيئية دهنية نانوية ذكية يتم توجيهها بدقة عبر الحقول الكهرومغناطيسية للاختراق غير المدمر للأغشية الخلوية path-specific.',
          capabilities: [
            'التحكم الدقيق في التوجيه المكاني عبر مجالات فيزيائية متعددة دون الحاجة لروابط كيميائية مضعفة',
            'ملاءمة ذاتية لمقاومة ميكانيكا السوائل جراء الدفق الدموي المتغير',
            'مراقبة فورية للمقاومة الكهربية متناهية الصغر داخل الخلايا'
          ],
          specs: [
            { name: 'متوسط القطر المحدد', value: '15.4 نانومتر ± 0.8 نانومتر' },
            { name: 'معدل تحميل الدواء المدمج', value: '≥ 94.2%' },
            { name: 'وقت استجابة إطلاق الجرعة', value: 'متحكم به على مستوى الميكروثانية' }
          ],
          problem: 'طرق الإيصال الدوائي الكلاسيكية تفتقر للتحديد الدقيق مما يتسبب في تسمم الأنسجة السليمة المحيطة وفقدان كبير للجرعة الكيميائية قبل وصولها للخلية المستهدفة.',
          approach: 'يستخدم Vector-X10 الانتقال الطوري الفيزيائي الدقيق المحفز بموجات خارجية آمنة وموجهة لمنع التحلل المبكر وإطلاق الحمولة بأعلى دقة ذرية.'
        },
        {
          id: 'quantum-diagnostics',
          name: 'AufMed Chronos-Spectrum',
          category: 'ماسح كمي ثلاثي الأبعاد فائق الحساسية للخلايا الحية',
          desc: 'نظام تشخيص خلوي غير باضع ودون الحاجة لأصباغ ليرصد ويحلل التغيرات الفسيولوجية فائق السرعة على المستوى دون الخلوي.',
          capabilities: [
            'رسم خرائط طيفية غير مدمرة بالليزر فائق السرعة بالفمتوثانية',
            'تصحيح تشوه النفاذ الضوئي للأنسجة العميقة بنماذج الترابط الرياضي',
            'عمل خرائط تماثلية جينية epigenetics فورية لتوائم الخلايا الرقمية'
          ],
          specs: [
            { name: 'الدقة الجانبية', value: '4.2 أنغستروم (دقة متناهية الصغر)' },
            { name: 'معدل أخذ العينات', value: '< 2.4 فيمتوثانية' },
            { name: 'عمق الاختراق الضوئي', value: 'يصل إلى 800 ميكرومتر في الأنسجة الحية' }
          ],
          problem: 'طرق التشخيص التقليدية التي تعتمد على الصبغ الكيميائي تؤدي لقتل الخلايا الحية تدريجيًا مما يعطل فهم التفاعلات الطويلة والمسارات الطبيعية.',
          approach: 'يقوم Chronos-Spectrum بقياس تشتت رامان الذاتي والتقاط التفاعل الخفيف الفوري، منتجاً لقطات حية سينمائية فائقة النقاء والخلو من السموم.'
        },
        {
          id: 'neural-interface',
          name: 'AufMed Synapse-Link',
          category: 'مصفوفة أقطاب مرنة عالية الكثافة للاقتران المشبكي',
          desc: 'واجهة دماغية عصبية مصنوعة من بوليمر كربون متين فائق المرونة لدراسة وإعادة بناء المسارات العصبية الحركية وتجانس الحقول الحيوية.',
          capabilities: [
            'غطاء غشائي كربوني مسامي داعم للتنفس والتواؤم المتناغم للخلايا الدبقية المجاورة',
            'مصفوفة تضم 2048 قطباً كهرومغنائياً دقيقاً ذاتية الملاءمة للمقاومة العصبية',
            'وحدة معالجة طرفية لفك تشفير الأنماط العصبية المعقدة بنماذج التعلم العميق'
          ],
          specs: [
            { name: 'مصفوفة التوصيل الكهربي', value: '1.2 × 10^4 سيمنز/متر' },
            { name: 'الجهد الكهربي المستقر', value: '< 10 ميكروفولت' },
            { name: 'سمك قاعدة الدعم المرنة', value: '3.5 ميكرومتر (رقة فائقة)' }
          ],
          problem: 'الأقطاب الكهربائية المعدنية الصلبة تثير ردود فعل مناعية عنيفة تؤدي لتكون أنسجة ندبية تعطل توصيل الإشارات الكهربية بمرور الوقت.',
          approach: 'يستخدم Synapse-Link بنية تحاكي تموج الأنسجة الجنينية مما يشجع الخلايا الدبقية الطبيعية على التآزر مع القطب واعتباره جزءاً حيوياً آمناً.'
        }
      ]
    },
    contact: {
      badge: 'اتصال مشفر وآمن',
      title: 'تواصل مع مهندسي الابتكار في AufMed',
      subtitle: 'نقدم استشارات متخصصة لتطوير النظم، والتعاون الإكلينيكي المعتمد، والتصميم المشترك للعلامات والمنتجات التكنولوجية فائقة الجودة.',
      hqTitle: 'المراكز العالمية للتميز',
      hqAddress: 'المقر الرئيسي بميونخ: Leopoldstraße 244, 80807 München, Germany\nأكاديمية شنغهاي للتصميم: شارع بينجيانغ 200، شنغهاي، الصين',
      phone: '+49 89 2349 924 // +86 21 6811 0924',
      email: 'partnerships@aufmed.com',
      formName: 'الاسم الكريم واللقب العلمي',
      formOrg: 'اسم المؤسسة / المختبر التابع له',
      formInquiryType: 'مسار الاستفسار',
      formInquiryOptions: [
        'بحث وتطوير مشترك مع مؤسسات أكاديمية R&D',
        'تجارب سريرية مخصصة ونشر أجهزة تحت الترخيص',
        'التصميم الطبي المشترك والحلول الجمالية وإرشاد الهوية',
        'الاستثمارات الرأسمالية والشركاء الاستراتيجيين'
      ],
      formMessage: 'وصف تخطيطي موجز لبروتوكول التعاون والتطلعات',
      formSubmit: 'إرسال طلب آمن ومشفر',
      successMessage: 'تم تشفير طلبك بأمان وإرساله إلى فريق التواصل والمستشارين العلميين في AufMed. سيقوم ممثل مختص بالرد والتنسيق معك خلال 24 ساعة.',
      placeholderName: 'على سبيل المثال: د. ليلى يوسف',
      placeholderOrg: 'على سبيل المثال: مختبر الحوسبة والجسيمات الحيوية بمعهد ماساتشوستس',
      placeholderMessage: 'يرجى وضع تلخيص سريع لنمط بحثك الفسيولوجي الحالي وما هي أنظمة AufMed التي تتطلع لتضمينها لتسريع خطتك.'
    },
    footer: {
      tagline: 'نصيغ تسلسل الحياة بأناقة الفيزياء وهندسة الجمال.',
      legal: 'AufMed للتقنيات الطبية المحدودة GmbH © جميع الحقوق محفوظة.',
      allRightsReserved: 'مرخص للاستخدام في شبكات التطوير والبحوث السريرية المتقدمة.',
      designerIdentity: 'صُمم بواسطة ستديو AufMed المرئي // قطاع الابتكار والذكاء الاصطناعي والهوية'
    }
  }
};
