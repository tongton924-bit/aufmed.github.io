import { useState } from 'react';
import { Building, CheckCircle2, Milestone as MilestoneIcon } from 'lucide-react';
import { TranslationSchema, Milestone } from '../types';

interface AboutSectionProps {
  t: TranslationSchema;
  hqImgUrl: string;
}

export default function AboutSection({ t, hqImgUrl }: AboutSectionProps) {
  const [activeMilestoneIndex, setActiveMilestoneIndex] = useState(t.intro.milestones.length - 1);
  const isRtl = t.dir === 'rtl';

  return (
    <section
      id="about"
      className="py-24 bg-pitch-black border-t border-white/10 relative overflow-hidden"
    >
      {/* Background Ambience */}
      <div className="absolute top-1/3 left-10 w-96 h-96 bg-cyber-cyan/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        {/* Module Header layout */}
        <div className={`mb-20 ${isRtl ? 'text-right' : 'text-left'}`}>
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-white/10 bg-black text-cyber-cyan font-mono text-[10px] tracking-[0.25em] uppercase mb-4">
            <Building className="w-3.5 h-3.5" />
            <span>{t.intro.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tighter leading-[0.95] uppercase">
            {t.intro.title}
          </h2>
          <p className="text-white/55 font-mono text-xs sm:text-sm mt-4 uppercase tracking-[0.15em] max-w-2xl">
            {t.intro.subtitle}
          </p>
        </div>

        {/* Column 1: Identity Cards & Stats Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-20">
          <div className="lg:col-span-7 space-y-8">
            <div className="border border-white/10 bg-black p-8 sm:p-10 rounded-none relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-cyber-cyan/10 to-transparent blur-xl" />
              <div className="space-y-6 text-white/75 font-sans text-sm sm:text-base leading-relaxed">
                {t.intro.paragraphs.map((p, i) => (
                  <p key={i} className="border-l-2 border-white/15 pl-4">{p}</p>
                ))}
              </div>
            </div>

            {/* Premium Sharp Stat Indicators - Bold Typography Theme */}
            <div className="grid grid-cols-2 gap-4">
              {t.intro.stats.map((stat, i) => (
                <div
                  key={i}
                  className="group relative border border-white/10 hover:border-cyber-cyan/40 bg-black p-6 rounded-none transition-all duration-300"
                >
                  <span className="block font-mono text-3xl sm:text-4xl font-extrabold text-white tracking-tighter mb-1.5">
                    {stat.value}
                  </span>
                  <span className="block font-mono text-[9px] sm:text-[10px] text-white/40 tracking-widest uppercase font-bold">
                    {stat.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Corporate Preview Frame with sharp geometric borders */}
          <div className="lg:col-span-5 relative group">
            <div className="relative border border-white/10 bg-black p-3 rounded-none overflow-hidden aspect-[4/3] w-full">
              <img
                src={hqImgUrl}
                alt="AufMed Creative and Clinical excellence HQ"
                className="w-full h-full object-cover filter grayscale contrast-[1.10] group-hover:grayscale-0 transition duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-x-3 bottom-3 bg-black border border-white/15 p-4 rounded-none flex items-center justify-between">
                <div>
                  <span className="block text-[10px] font-mono text-cyber-cyan font-bold tracking-widest uppercase">
                    MÜNCHEN & SHANGHAI
                  </span>
                  <span className="block text-[8px] sm:text-[9px] font-mono text-white/40 mt-0.5 uppercase tracking-widest">
                    R&D AND HMI DESIGN HUBS
                  </span>
                </div>
                <div className="flex gap-1.5">
                  <span className="w-2 h-2 bg-cyber-cyan animate-pulse"></span>
                  <span className="w-2 h-2 bg-white/20"></span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Column 2: Milestones Interactive Path - Pure Architectural Rectilinear Styling */}
        <div className="border border-white/10 bg-black p-6 sm:p-10 rounded-none relative">
          <div className="flex items-center gap-2 mb-8 border-b border-white/10 pb-4">
            <MilestoneIcon className="w-4 h-4 text-cyber-cyan" />
            <span className="font-mono text-xs uppercase font-bold tracking-widest text-white">
              {t.intro.milestonesTitle}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Year Selector buttons */}
            <div className="md:col-span-4 flex md:flex-col gap-2 overflow-x-auto md:overflow-x-visible pb-3 md:pb-0 scrollbar-none snap-x">
              {t.intro.milestones.map((m: Milestone, idx: number) => (
                <button
                  key={m.year}
                  onClick={() => setActiveMilestoneIndex(idx)}
                  className={`snap-center flex-shrink-0 md:flex-shrink-0 px-4 py-3 border font-mono text-left transition-all duration-300 flex items-center justify-between md:w-full rounded-none uppercase ${
                    activeMilestoneIndex === idx
                      ? 'bg-white border-white text-black font-black'
                      : 'bg-transparent border-white/10 text-white/40 hover:border-white/30 hover:text-white'
                  }`}
                >
                  <span className="text-xs font-black tracking-widest">{m.year}</span>
                  <span className={`h-1.5 w-1.5 transition-transform ${activeMilestoneIndex === idx ? 'bg-black' : 'bg-white/20'}`}></span>
                </button>
              ))}
            </div>

            {/* Active Year detail card with intense minimalist typographic focus */}
            <div className="md:col-span-8 min-h-[160px] flex flex-col justify-center border border-white/10 bg-pitch-black p-8 rounded-none relative overflow-hidden">
              <div className="absolute top-2 right-4 font-mono text-[72px] font-black text-white/5 leading-none select-none pointer-events-none tracking-tighter">
                {t.intro.milestones[activeMilestoneIndex].year}
              </div>
              <h4 className="text-white text-base sm:text-lg font-bold tracking-tight mb-3 flex items-center gap-3">
                <CheckCircle2 className="w-4 h-4 text-cyber-cyan flex-shrink-0" />
                <span className="uppercase tracking-tight font-sans font-black text-white">{t.intro.milestones[activeMilestoneIndex].title}</span>
              </h4>
              <p className="text-white/60 font-sans text-xs sm:text-sm leading-relaxed max-w-2xl">
                {t.intro.milestones[activeMilestoneIndex].desc}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
