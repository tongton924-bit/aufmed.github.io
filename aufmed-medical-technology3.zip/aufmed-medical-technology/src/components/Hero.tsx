import { Sparkles, Atom } from 'lucide-react';
import { TranslationSchema } from '../types';

interface HeroProps {
  t: TranslationSchema;
  heroBgUrl: string;
}

export default function Hero({ t, heroBgUrl }: HeroProps) {
  const isRtl = t.dir === 'rtl';

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-32 pb-24 overflow-hidden bg-pitch-black"
    >
      {/* High-Impact Visual Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroBgUrl}
          alt="AufMed High Accuracy Advanced Nanophysics Platform"
          className="w-full h-full object-cover object-center opacity-30 mix-blend-luminosity scale-105 filter brightness-[0.6] contrast-[1.15]"
          referrerPolicy="no-referrer"
        />
        {/* Soft custom radial masking and dark gradient */}
        <div className="absolute inset-0 bg-radial-[circle_at_center,transparent_15%,#050505_90%]" />
        <div className="absolute inset-0 bg-gradient-to-t from-pitch-black via-transparent to-pitch-black/80" />

        {/* Ambient subtle glowing tech line */}
        <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-cyber-cyan/45 to-transparent blur-xs"></div>
      </div>

      {/* Main Container - Desktop-friendly high-rhythm composition */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 sm:px-8 flex flex-col items-center text-center">
        {/* Fine Floating Micro-Badge */}
        <div className="inline-flex items-center gap-3 px-4 py-2 border border-white/10 bg-black/85 backdrop-blur-md mb-8 animate-fade-in shadow-[0_0_20px_rgba(0,229,255,0.08)]">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyber-cyan opacity-80"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyber-cyan"></span>
          </span>
          <span className="font-mono text-[10px] tracking-[0.3em] text-cyber-cyan uppercase font-bold">
            {t.hero.badge}
          </span>
        </div>

        {/* Giant Display Title - Masterpiece of Bold Monotonous & High Contrast Typo */}
        <h1
          id="hero-primary-text"
          className="font-sans text-4xl sm:text-6xl md:text-8xl font-black tracking-tighter text-white mb-8 leading-[0.85] uppercase max-w-5xl"
          style={{ direction: t.dir }}
        >
          <span className="block opacity-95">{t.hero.title}</span>
          <span className="block mt-4 text-cyber-cyan italic font-extralight tracking-tight lowercase text-3xl sm:text-5xl md:text-6xl font-mono normal-case">
            {t.hero.highlight}
          </span>
        </h1>

        {/* Description - styled precisely as the bold typography reference (italicised, border left accent) */}
        <div 
          className="max-w-xl mx-auto mb-12 flex justify-center text-left"
          style={{ direction: t.dir }}
        >
          <p
            id="hero-subtitle"
            className={`font-sans text-sm sm:text-base text-white/60 leading-relaxed italic border-l-2 border-cyber-cyan pl-5 py-1 ${isRtl ? 'border-r-2 border-l-0 pr-5 pl-0 text-right' : ''}`}
          >
            {t.hero.subtitle}
          </p>
        </div>

        {/* Actions with sharp borders, uppercase bold fonts */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto"
          style={{ direction: t.dir }}
        >
          <a
            id="hero-cta-primary"
            href="#products"
            className="w-full sm:w-auto px-8 py-4 bg-white text-black hover:bg-cyber-cyan font-sans tracking-widest text-[11px] font-black uppercase transition-all duration-300 shadow-2xl flex items-center justify-center gap-2.5 rounded-none"
          >
            <span>{t.hero.ctaPrimary}</span>
            <Atom className="w-4 h-4 text-black group-hover:rotate-95 transition-transform" />
          </a>

          <a
            id="hero-cta-secondary"
            href="#contact"
            className="w-full sm:w-auto px-8 py-4 bg-black border border-white/20 hover:border-cyber-cyan/50 hover:text-cyber-cyan text-white/80 font-sans tracking-widest text-[11px] font-black uppercase transition-all duration-300 flex items-center justify-center gap-2 rounded-none"
          >
            <span>{t.hero.ctaSecondary}</span>
            <span className="font-mono text-cyber-cyan">→</span>
          </a>
        </div>
      </div>

      {/* Decorative architectural info panels - high fidelity styling */}
      <div className="absolute left-8 bottom-8 hidden xl:flex flex-col gap-1 font-mono text-[9px] tracking-[0.25em] text-white/30 uppercase select-none">
        <span>AUFMED DIGITAL CORP // SPEC_A9</span>
        <span>CELLULAR COMPOSITING ENGINE</span>
      </div>
      <div className="absolute right-8 bottom-8 hidden xl:flex flex-col gap-1 font-mono text-[9px] tracking-[0.25em] text-white/30 uppercase text-right select-none">
        <span>STABLE CONVERGENCE INDEX: 99.8%</span>
        <span>LATENCY TIMESPACE: 0.12fs</span>
      </div>
    </section>
  );
}
