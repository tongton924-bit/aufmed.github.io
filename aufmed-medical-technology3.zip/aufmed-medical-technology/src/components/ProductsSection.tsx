import { useState } from 'react';
import { Microscope, Cpu, Sparkles, CheckCircle2, ChevronRight, Activity, Zap } from 'lucide-react';
import { TranslationSchema, ProductItem } from '../types';

interface ProductsSectionProps {
  t: TranslationSchema;
  productImgUrl: string;
}

export default function ProductsSection({ t, productImgUrl }: ProductsSectionProps) {
  const [selectedProductId, setSelectedProductId] = useState(t.products.items[0].id);
  const isRtl = t.dir === 'rtl';

  const selectedProduct = t.products.items.find(item => item.id === selectedProductId) || t.products.items[0];

  const getProductIcon = (id: string) => {
    switch (id) {
      case 'molecular-delivery':
        return <Activity className="w-5 h-5 text-cyber-cyan group-hover:scale-110 transition-transform" />;
      case 'quantum-diagnostics':
        return <Microscope className="w-5 h-5 text-cyber-cyan group-hover:scale-110 transition-transform" />;
      case 'neural-interface':
        return <Cpu className="w-5 h-5 text-cyber-cyan group-hover:scale-110 transition-transform" />;
      default:
        return <Sparkles className="w-5 h-5 text-cyber-cyan group-hover:scale-110 transition-transform" />;
    }
  };

  return (
    <section
      id="products"
      className="py-24 bg-pitch-black border-t border-white/10 relative overflow-hidden"
    >
      <div className="absolute top-1/2 right-1/4 w-[500px] h-[500px] bg-cyber-cyan/[0.02] rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        {/* Section Header */}
        <div className={`mb-20 ${isRtl ? 'text-right' : 'text-left'}`}>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 border border-white/10 bg-black text-cyber-cyan font-mono text-[10px] tracking-[0.25em] uppercase mb-4 animate-fade-in">
            <Zap className="w-3.5 h-3.5" />
            <span>{t.products.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tighter leading-[0.95] uppercase">
            {t.products.title}
          </h2>
          <p className="text-white/55 font-mono text-xs sm:text-sm mt-4 uppercase tracking-[0.15em] max-w-2xl">
            {t.products.subtitle}
          </p>
        </div>

        {/* Major Modular Layout (List on Left, Dynamic Panel + Interactive Graphics on Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Interactive Product Selector Cards (No rounding, sharp contrast) */}
          <div className="lg:col-span-5 space-y-4">
            {t.products.items.map((item: ProductItem) => {
              const isSelected = item.id === selectedProductId;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedProductId(item.id)}
                  className={`w-full text-left p-6 sm:p-8 rounded-none border transition-all duration-300 relative group flex flex-col justify-between ${
                    isSelected
                      ? 'bg-black border-cyber-cyan shadow-[0_0_25px_rgba(0,229,255,0.08)]'
                      : 'bg-black/35 border-white/10 hover:border-white/30 text-white/55'
                  }`}
                  style={{ direction: t.dir }}
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-none border transition ${
                      isSelected
                        ? 'bg-cyber-cyan/15 border-cyber-cyan text-white'
                        : 'bg-black border-white/10 text-white/40'
                    }`}>
                      {getProductIcon(item.id)}
                    </div>
                    <div className="space-y-1.5">
                      <span className="block font-mono text-[9px] tracking-widest text-cyber-cyan font-bold uppercase">
                        {item.category}
                      </span>
                      <h3 className={`text-base font-bold tracking-tight uppercase font-sans transition ${isSelected ? 'text-white' : 'text-white/80 group-hover:text-white'}`}>
                        {item.name}
                      </h3>
                      <p className="text-xs text-white/40 font-light line-clamp-2 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>

                  <div className={`mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-[10px] font-mono tracking-widest uppercase ${
                    isSelected ? 'text-cyber-cyan' : 'text-white/30'
                  }`}>
                    <span>{t.products.viewDetails}</span>
                    <ChevronRight className={`w-3.5 h-3.5 transform transition-transform ${isSelected ? 'translate-x-1' : ''}`} />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column: High-Fidelity Active Parameters Panel */}
          <div className="lg:col-span-7 border border-white/10 bg-black rounded-none p-6 sm:p-10 relative overflow-hidden space-y-8">
            <div className="absolute top-0 right-0 w-44 h-44 bg-gradient-to-br from-cyber-cyan/5 to-transparent blur-2xl" />

            {/* Active Header */}
            <div className="border-b border-white/10 pb-5" style={{ direction: t.dir }}>
              <span className="font-mono text-[10px] tracking-widest text-cyber-cyan font-semibold uppercase block mb-1">
                {selectedProduct.category}
              </span>
              <h3 className="text-white text-2xl sm:text-3xl font-black uppercase tracking-tight">
                {selectedProduct.name}
              </h3>
            </div>

            {/* Sub-cellular Capabilities list */}
            <div className="space-y-4" style={{ direction: t.dir }}>
              <h4 className="font-mono text-[10px] font-black text-white uppercase tracking-widest flex items-center gap-2">
                <span className="h-1.5 w-1.5 bg-cyber-cyan"></span>
                <span>{t.products.capabilitiesTitle}</span>
              </h4>
              <ul className="space-y-3">
                {selectedProduct.capabilities.map((cap, i) => (
                  <li key={i} className="flex items-start gap-3 text-white/70 text-xs sm:text-sm">
                    <CheckCircle2 className="w-4 h-4 text-cyber-cyan mt-0.5 flex-shrink-0" />
                    <span>{cap}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Academic Specs parameters Grid (Monospace spec value styling) */}
            <div className="pt-2" style={{ direction: t.dir }}>
              <h4 className="font-mono text-[10px] font-black text-white uppercase tracking-widest mb-4 flex items-center gap-2">
                <span className="h-1.5 w-1.5 bg-cyber-cyan"></span>
                <span>{t.products.specsTitle}</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {selectedProduct.specs.map((spec, i) => (
                  <div key={i} className="border border-white/10 bg-pitch-black p-4 rounded-none">
                    <span className="block font-mono text-[9px] text-white/40 uppercase tracking-widest font-bold mb-1">
                      {spec.name}
                    </span>
                    <span className="block font-mono text-sm font-black text-cyber-cyan tracking-tight uppercase">
                      {spec.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Problem solved vs. Approach layout */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-6 border-t border-white/10 text-xs sm:text-sm" style={{ direction: t.dir }}>
              <div className="space-y-2">
                <span className="font-mono text-[10px] text-red-400 font-bold uppercase tracking-widest block">
                  {t.products.problemTitle}
                </span>
                <p className="text-white/50 leading-relaxed">
                  {selectedProduct.problem}
                </p>
              </div>
              <div className="space-y-2 border-t sm:border-t-0 sm:border-l border-white/10 pt-6 sm:pt-0 sm:pl-6">
                <span className="font-mono text-[10px] text-cyber-cyan font-bold uppercase tracking-widest block">
                  {t.products.approachTitle}
                </span>
                <p className="text-white/70 leading-relaxed italic border-l-2 border-cyber-cyan/30 pl-3">
                  {selectedProduct.approach}
                </p>
              </div>
            </div>

            {/* Embed realistic medical hardware engineering graphic */}
            <div className="relative rounded-none overflow-hidden aspect-[16/6] border border-white/15 mt-4">
              <img
                src={productImgUrl}
                alt="AufMed system active rendering module representation"
                className="w-full h-full object-cover filter brightness-[0.70] contrast-[1.15] select-none"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/35" />
              <div className="absolute top-2 right-3 font-mono text-[8px] text-cyber-cyan tracking-widest font-bold uppercase">
                AUFMED ANALYZER SYSTEMS // ONLINE
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
