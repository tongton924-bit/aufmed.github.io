import { useState, useEffect } from 'react';
import { Globe, Menu, X, Sparkles, ChevronDown } from 'lucide-react';
import { translations, TranslationSchema } from '../types';

interface HeaderProps {
  currentLang: string;
  setLang: (lang: string) => void;
  t: TranslationSchema;
}

const languages = [
  { code: 'zh', label: '简体中文' },
  { code: 'en', label: 'English' },
  { code: 'de', label: 'Deutsch' },
  { code: 'fr', label: 'Français' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'es', label: 'Español' },
  { code: 'ar', label: 'العربية' },
];

export default function Header({ currentLang, setLang, t }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLangSelect = (code: string) => {
    setLang(code);
    setShowLangMenu(false);
  };

  return (
    <header
      id="aufmed-global-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 border-b ${
        scrolled
          ? 'bg-black/90 backdrop-blur-xl border-white/10 shadow-2xl'
          : 'bg-transparent border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-22 flex items-center justify-between">
        {/* Logo and Brand - High Impact Bold Typography Mode */}
        <a
          id="brand-logo-link"
          href="#home"
          className="flex items-baseline gap-2 group transition"
        >
          <div className="text-2xl sm:text-3xl font-black tracking-tighter italic text-white uppercase font-sans">
            AUFMED<span className="text-cyber-cyan">.</span>
          </div>
          <span className="font-mono text-[9px] tracking-[0.25em] text-white/40 uppercase hidden sm:inline-block">
            Systems
          </span>
        </a>

        {/* Desktop Navigation - Low density uppercase tracking */}
        <nav id="desktop-navbar" className="hidden md:flex items-center gap-8 text-[11px] uppercase tracking-[0.25em]">
          <a
            id="nav-home"
            href="#home"
            className="font-semibold text-white/55 hover:text-cyber-cyan transition-colors"
          >
            {t.nav.home}
          </a>
          <a
            id="nav-about"
            href="#about"
            className="font-semibold text-white/55 hover:text-cyber-cyan transition-colors"
          >
            {t.nav.about}
          </a>
          <a
            id="nav-products"
            href="#products"
            className="font-semibold text-white/55 hover:text-cyber-cyan transition-colors"
          >
            {t.nav.products}
          </a>
          <a
            id="nav-contact"
            href="#contact"
            className="font-semibold text-white/55 hover:text-cyber-cyan transition-colors"
          >
            {t.nav.contact}
          </a>
        </nav>

        {/* Actions & Language Select */}
        <div className="hidden md:flex items-center gap-4">
          {/* Custom Lang Selector */}
          <div className="relative">
            <button
              id="lang-selector-btn"
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-2 px-4 py-2 border border-white/15 bg-black/90 text-white/80 hover:text-cyber-cyan hover:border-cyber-cyan/50 transition rounded-none"
            >
              <Globe className="w-3.5 h-3.5 text-cyber-cyan" />
              <span className="font-mono text-[10px] uppercase tracking-widest">{currentLang}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${showLangMenu ? 'rotate-180' : ''}`} />
            </button>

            {showLangMenu && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setShowLangMenu(false)}
                />
                <div className="absolute right-0 mt-2 w-48 bg-black border border-white/15 rounded-none shadow-2xl p-2 z-20 animate-fade-in">
                  <div className="text-[10px] text-white/40 font-mono tracking-widest px-2.5 py-1.5 uppercase border-b border-white/10 mb-1">
                    Select Language
                  </div>
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => handleLangSelect(lang.code)}
                      className={`w-full text-left font-sans text-xs px-3 py-2 rounded-none transition flex items-center justify-between ${
                        currentLang === lang.code
                          ? 'bg-cyber-cyan/15 text-cyber-cyan font-bold border-l-2 border-cyber-cyan'
                          : 'text-white/60 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <span className="uppercase tracking-widest">{lang.label}</span>
                      <span className="font-mono text-[9px] uppercase opacity-60">{lang.code}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <a
            id="header-cta-btn"
            href="#contact"
            className="relative px-6 py-2.5 bg-white text-black text-[11px] font-bold uppercase rounded-none hover:bg-cyber-cyan transition-all duration-300 shadow-xl"
          >
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="font-sans tracking-widest uppercase">
                INQUIRY
              </span>
            </div>
          </a>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex md:hidden items-center gap-3">
          {/* Mobile Language Selector */}
          <div className="relative">
            <button
              id="mobile-lang-btn"
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 p-2.5 border border-white/15 bg-black text-white"
            >
              <Globe className="w-4 h-4 text-cyber-cyan" />
              <span className="font-mono text-xs uppercase font-bold">{currentLang}</span>
            </button>
            {showLangMenu && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowLangMenu(false)} />
                <div className="absolute right-0 mt-2 w-40 bg-black border border-white/10 rounded-none shadow-2xl p-1 z-20">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => handleLangSelect(lang.code)}
                      className="w-full text-left text-xs px-3 py-2 text-white/70 hover:bg-white/5 uppercase"
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <button
            id="mobile-hamburger-btn"
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 border border-white/15 bg-black text-white hover:text-cyber-cyan transition"
          >
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="md:hidden bg-black border-b border-white/10 animate-slide-down">
          <nav className="flex flex-col gap-4 px-6 py-8 font-sans text-xs uppercase tracking-widest">
            <a
              id="mobile-nav-home"
              href="#home"
              onClick={() => setIsOpen(false)}
              className="font-bold text-white/70 hover:text-cyber-cyan py-1"
            >
              {t.nav.home}
            </a>
            <a
              id="mobile-nav-about"
              href="#about"
              onClick={() => setIsOpen(false)}
              className="font-bold text-white/70 hover:text-cyber-cyan py-1"
            >
              {t.nav.about}
            </a>
            <a
              id="mobile-nav-products"
              href="#products"
              onClick={() => setIsOpen(false)}
              className="font-bold text-white/70 hover:text-cyber-cyan py-1"
            >
              {t.nav.products}
            </a>
            <a
              id="mobile-nav-contact"
              href="#contact"
              onClick={() => setIsOpen(false)}
              className="font-bold text-white/70 hover:text-cyber-cyan py-1"
            >
              {t.nav.contact}
            </a>

            <div className="h-px bg-white/10 my-2" />

            <a
              id="mobile-nav-cta"
              href="#contact"
              onClick={() => setIsOpen(false)}
              className="w-full text-center py-3 bg-white text-black font-black uppercase text-xs tracking-widest"
            >
              INQUIRY
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
