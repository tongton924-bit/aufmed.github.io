import { useState, FormEvent } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, Lock } from 'lucide-react';
import { TranslationSchema } from '../types';

interface ContactSectionProps {
  t: TranslationSchema;
}

export default function ContactSection({ t }: ContactSectionProps) {
  const [formData, setFormData] = useState({
    name: '',
    org: '',
    inquiryType: t.contact.formInquiryOptions[0],
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const isRtl = t.dir === 'rtl';

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate high-security encrypted dispatch delay
    setTimeout(() => {
      setLoading(false);
      setIsSubmitted(true);
      setFormData({
        name: '',
        org: '',
        inquiryType: t.contact.formInquiryOptions[0],
        message: '',
      });
    }, 1200);
  };

  return (
    <section
      id="contact"
      className="py-24 bg-pitch-black border-t border-white/10 relative overflow-hidden"
    >
      {/* Decorative Grid backdrop layer for architectural depth */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#111_1px,transparent_1px),linear-gradient(to_bottom,#111_1px,transparent_1px)] bg-[size:3.5rem_3.5rem] opacity-35 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        {/* Module Header */}
        <div className={`mb-20 ${isRtl ? 'text-right' : 'text-left'}`}>
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-white/10 bg-black text-cyber-cyan font-mono text-[10px] tracking-[0.25em] uppercase mb-4">
            <Lock className="w-3.5 h-3.5" />
            <span>{t.contact.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tighter leading-[0.95] uppercase">
            {t.contact.title}
          </h2>
          <p className="text-white/55 font-mono text-xs sm:text-sm mt-4 uppercase tracking-[0.15em] max-w-2xl">
            {t.contact.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Block: Corporate Information Directory (Sharp, high contrast) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="border border-white/10 bg-black p-8 sm:p-10 rounded-none relative space-y-8" style={{ direction: t.dir }}>
              <div className="space-y-4">
                <span className="font-mono text-[10px] text-cyber-cyan font-bold tracking-widest uppercase block">
                  {t.contact.hqTitle}
                </span>
                <div className={`flex gap-3 text-white/80 font-sans text-sm leading-relaxed ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}>
                  <MapPin className="w-4 h-4 text-cyber-cyan mt-1 flex-shrink-0" />
                  <p className="whitespace-pre-line">{t.contact.hqAddress}</p>
                </div>
              </div>

              <div className="h-px bg-white/10" />

              {/* Direct Communications */}
              <div className="space-y-4 font-mono text-xs text-white/60">
                <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}>
                  <Phone className="w-4 h-4 text-white/30 flex-shrink-0" />
                  <span>{t.contact.phone}</span>
                </div>
                <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}>
                  <Mail className="w-4 h-4 text-cyber-cyan flex-shrink-0" />
                  <span className="text-cyber-cyan hover:underline cursor-pointer font-bold">{t.contact.email}</span>
                </div>
              </div>

              <div className="p-4 border border-cyber-cyan/20 bg-cyber-cyan/5 flex items-start gap-3 rounded-none">
                <Lock className="w-4 h-4 text-cyber-cyan mt-0.5 flex-shrink-0" />
                <span className="font-sans text-[11px] leading-relaxed text-cyber-cyan/90">
                  AufMed safeguards proprietary intelligence using military-grade asymmetrical key cryptography. Your partnership inquiry remains confidential.
                </span>
              </div>
            </div>
          </div>

          {/* Right Block: Secure Encrypted Submission Form with Zero Corners */}
          <div className="lg:col-span-7">
            <div className="border border-white/10 bg-black p-8 sm:p-10 rounded-none relative">
              {isSubmitted ? (
                <div className="py-12 px-4 text-center space-y-6 animate-fade-in">
                  <div className="mx-auto w-12 h-12 rounded-none border border-cyber-cyan bg-cyber-cyan/10 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-cyber-cyan" />
                  </div>
                  <h3 className="text-white text-xl font-bold tracking-tight uppercase">
                    Transmission Authorized
                  </h3>
                  <p className="max-w-md mx-auto text-white/60 font-sans text-xs sm:text-sm leading-relaxed">
                    {t.contact.successMessage}
                  </p>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="mt-4 px-8 py-3 bg-white hover:bg-cyber-cyan text-black text-[11px] font-bold uppercase tracking-widest transition-colors duration-300"
                  >
                    Send Another Dispatch
                  </button>
                </div>
              ) : (
                <form id="secure-contact-form" onSubmit={handleSubmit} className="space-y-6" style={{ direction: t.dir }}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Name */}
                    <div className={`space-y-2 ${isRtl ? 'text-right' : 'text-left'}`}>
                      <label className="block font-mono text-[9px] text-white/40 tracking-widest uppercase font-bold">
                        {t.contact.formName}
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder={t.contact.placeholderName}
                        className={`w-full px-4 py-3.5 border border-white/10 bg-pitch-black hover:border-white/20 focus:border-cyber-cyan text-sm font-sans text-white placeholder-white/25 transition outline-none rounded-none ${isRtl ? 'text-right' : 'text-left'}`}
                      />
                    </div>

                    {/* Organization */}
                    <div className={`space-y-2 ${isRtl ? 'text-right' : 'text-left'}`}>
                      <label className="block font-mono text-[9px] text-white/40 tracking-widest uppercase font-bold">
                        {t.contact.formOrg}
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.org}
                        onChange={(e) => setFormData({ ...formData, org: e.target.value })}
                        placeholder={t.contact.placeholderOrg}
                        className={`w-full px-4 py-3.5 border border-white/10 bg-pitch-black hover:border-white/20 focus:border-cyber-cyan text-sm font-sans text-white placeholder-white/25 transition outline-none rounded-none ${isRtl ? 'text-right' : 'text-left'}`}
                      />
                    </div>
                  </div>

                  {/* Inquiry Type Dropdown selection */}
                  <div className={`space-y-2 ${isRtl ? 'text-right' : 'text-left'}`}>
                    <label className="block font-mono text-[9px] text-white/40 tracking-widest uppercase font-bold">
                      {t.contact.formInquiryType}
                    </label>
                    <div className="relative">
                      <select
                        value={formData.inquiryType}
                        onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                        className={`w-full appearance-none px-4 py-3.5 border border-white/10 bg-pitch-black text-sm font-sans text-white/80 transition focus:border-cyber-cyan outline-none cursor-pointer rounded-none ${isRtl ? 'text-right pr-4 pl-10' : 'text-left pl-4 pr-10'}`}
                      >
                        {t.contact.formInquiryOptions.map((opt, i) => (
                          <option key={i} value={opt} className="bg-pitch-black text-white">
                            {opt}
                          </option>
                        ))}
                      </select>
                      <div className={`pointer-events-none absolute inset-y-0 flex items-center px-4 ${isRtl ? 'left-0' : 'right-0'} text-white/40 text-xs`}>
                        ▼
                      </div>
                    </div>
                  </div>

                  {/* Message body */}
                  <div className={`space-y-2 ${isRtl ? 'text-right' : 'text-left'}`}>
                    <label className="block font-mono text-[9px] text-white/40 tracking-widest uppercase font-bold">
                      {t.contact.formMessage}
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder={t.contact.placeholderMessage}
                      className={`w-full px-4 py-3.5 border border-white/10 bg-pitch-black hover:border-white/20 focus:border-cyber-cyan text-sm font-sans text-white placeholder-white/25 transition outline-none resize-none rounded-none ${isRtl ? 'text-right' : 'text-left'}`}
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full h-12 bg-white text-black hover:bg-cyber-cyan font-mono text-xs font-black uppercase tracking-widest transition-colors duration-300 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 rounded-none shadow-xl"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2.5 font-sans">
                        <span className="w-1.5 h-1.5 bg-black animate-ping"></span>
                        ENCRYPTING TRANSMISSION...
                      </span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>{t.contact.formSubmit}</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
